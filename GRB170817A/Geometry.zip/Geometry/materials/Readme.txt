How to compile and launch the Absorption Calculator:

gmake -f ../../standalone/Makefile.StandAlone PRG=AbsorptionCalculator CMD="-f AbsorptionCalculator.geo.setup"